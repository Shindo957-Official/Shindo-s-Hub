document.addEventListener("DOMContentLoaded", function() {
    if(window.location.protocol === 'http:'){
        if (window.location.host === 'localhost'){
    
        }
        else if (window.location.host === '127.0.0.1'){
    
        }
        else{
            document.getElementById('uv-address').disabled = true;
            document.getElementById('uv-address').placeholder = 'please turn on HTTPS to use this site!';
        }
    }
});

const randomtextstuff = [
    "MANGO MANGO 💀🙏",
    "DOWN WITH BLOCKERS",
    '"faggot!" - szvy',
    "also try getaway shootout",
    "official frogie's arcade song goes hard",
    "we love frogie's arcade",
    "save your data!",
    "we dont talk about TBG95.",
    '"may you please add roblox???🥺"',
    "join the discord!",
    "search freely....",
    "all unblocked!",
    "oil up lil bro",
    "fa v4 when?",
    "stephanie.pillers@cfisd.net",
    "calvillo5432ud@gmail.com",
    "this is indeed a proxy",
    "whats on your mind?"
];
