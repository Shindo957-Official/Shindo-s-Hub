
![Logo](https://raw.githubusercontent.com/FrogiesArcade/akanedontrapeme/refs/heads/main/banner.png)


# frogie's arcade v3

its only the proxy part, just so akane wont rape me and my vps


## deployment

to run this:

```bash
  npm i
  cd static
  npm i
  cd ..
  npm i ./static
  npm start
```


## credits

frogiee1 - main site

55gms - some of the proxy

titaniumnetwork - ultraviolet

